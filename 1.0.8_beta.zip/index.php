<?php include("./templetea/htdoc.php") ?>
<?php include("./passmax/ass.php") ?>
<!DOCTYPE html>
<html lang="zh"> 
<head>
    <title><?php echo "$hometitle"; ?></title>
    <meta charset="UTF-8">
    <link rel="icon" href="<?php echo "$favicon"; ?>"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" integrity="sha512-c42qTSw/wPZ3/5LBzD+Bw5f7bSF2oxou6wEb+I/lqeaKV5FDIfMvvRp772y4jcJLKuGUOpbJMdg/BTl50fJYAw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="/mass/dist/style.css"> 
    <script>  
    var _hmt = _hmt || []; 
    (function() { 
    var hm = document.createElement("script"); 
    hm.src = "https://www.airli.cn/io/tongji/airli.php"; 
    var s = document.getElementsByTagName("script")[0]; 
    s.parentNode.insertBefore(hm, s); 
    })();  
    </script> 
</head>
<body>
<div class="bg"></div>
<div class="animation-wrapper">
<div class="particle particle-1"></div>
<div class="particle particle-2"></div>
<div class="particle particle-3"></div> 
<div class="particle particle-4"></div> 
</div>
    <div class="center">
        <div class="animate__animated animate__jackInTheBox">
            <h1><?php echo ''.$hometitle.''; ?></h1>
            <p><?php echo ''.$homecontent.''; ?></p>
            <div class="animate__animated animate__bounceIn animate__delay-1s">
                <a href="#"><button class="btn1"><i class="fab fa-discord"></i>首页</button></a>
                <a href="wzy.php"><button class="btn2"><i class="fas fa-shopping-basket"></i>文章页</button></a>
                <a href="zdy.php"><button class="btn3"><i class="fas fa-poll"></i>自定义页</button></a>
            </div>
        </div>
    </div>
</body>
</html>