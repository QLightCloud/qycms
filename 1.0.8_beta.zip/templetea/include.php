<?php
/**
 +-------------------------------------------------------------------------+
 |                           轻云科技旗下项目                              |
 |                                                                         |
 | Author: Jose Chen <jose@airli.cn>                                       |
 | Author: Airli Tian <im@airli.cn>                                        |
 +-------------------------------------------------------------------------+
*/
	date_default_timezone_set('PRC');
	@$string=file_get_contents('../index/txt/all.txt');
	if(!empty($string)){
		$string=rtrim($string,'₪₢');
		$arr=explode('₪₢',$string);
		foreach($arr as $value){
			list($favicon,$qq,$wzdurl)=explode('¤○',$value);
		}
	}
	date_default_timezone_set('PRC');
	@$string=file_get_contents('./index/txt/all.txt');
	if(!empty($string)){
		$string=rtrim($string,'₪₢');
		$arr=explode('₪₢',$string);
		foreach($arr as $value){
			list($favicon,$qq,$wzdurl)=explode('¤○',$value);
		}
	}
?>

<style>
.subbxiugai {
    background-color: #5c5cff; /* Green #4CAF50*/
    border: none;
    color: white;
    padding: 10px 15px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 15px;
}
</style>
    
    <style>
    .menuz {
    *{margin:0;padding: 0;list-style: none;text-decoration: none;}
    .menuz #nav{width: 500px;height: 40px;background: #CCC;margin: 0 auto;}
    .menuz ul{background: #EEE}
    .menuz ul li{float:left; display:block; height: 40px; line-height: 40px; padding: 0 20px; position: relative;}
    .menuz ul li:hover{background: #Cea;}
    .menuz ul li ul li{float: none;}
    /*关键一：将二级菜单设置为display：none;*/
    .menuz ul li ul{position: absolute;top:40px;left: 0; display: none;}
    .menuz ul li ul li:hover{background: red;}
    /*关键二：在划过二级菜单从属的一级菜单时，设置为display:block;*/
    .menuz ul li:hover ul{display: block;}
}
    </style>