<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>欢迎 | 轻云CMS安装</title>
        <link href="css/style.min.css" rel="stylesheet"/>

    </head>
    <body>
        <div class="master">
            <div class="box">
                <div class="header">
                    <h1 class="header__title">轻云CMS安装
</h1>
                </div>

                <div class="main">

      <div class="form-group">
        <label>恭喜安装完成，请自行删除install文件夹！</label>
        <label>后台地址：你的域名/admin</label>
      </div>
      </p>
    </form>
                </div>
            </div>
        </div>
                <script type="text/javascript">
            var x = document.getElementById('error_alert');
            var y = document.getElementById('close_alert');
            y.onclick = function() {
                x.style.display = "none";
            };
        </script>
    </body>
</html>



<?php
/**
<?php
/**
 +-------------------------------------------------------------------------+
 |                           轻云科技旗下项目                              |
 |                                                                         |
 | Author: Jose Chen <jose@airli.cn>                                       |
 | Author: Airli Tian <im@airli.cn>                                        |
 +-------------------------------------------------------------------------+
*/
/**
			echo '<!DOCTYPE html>';
			echo '<html lang="zh">';
			echo '<head>';
			echo '<meta charset="UTF-8">';
			echo '<title>轻云CMS - 安装</title>';
			echo '</head>';
			echo '<body>';
	@$string=file_get_contents('../index/txt/admin.txt');
	if(!empty($string)){
	$string=rtrim($string,'&^');
	$arr=explode('&^',$string);
	foreach($arr as $value){
			list($aduse,$adpass)=explode('$#',$value);
			echo '<form action="install1f.php" method="post">';
			echo '后台账号：<input type="text" name="aduse" value="" ><br/>';
			echo '后台密码：<input type="text" name="adpass" value="" ><br/>';
			echo '<input type="submit" value="下一步"/>';
			echo '</form>';
			echo '</body></html>';
		}
	}
?>
*/
?>