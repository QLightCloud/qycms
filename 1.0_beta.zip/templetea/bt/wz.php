<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="//cdn.bootcss.com/bootstrap/3.3.4/css/bootstrap.min.css">
<script src="https://cdn.bootcss.com/jquery/1.11.2/jquery.min.js"></script>
<script src="https://cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</head>
<?php
/**
 +-------------------------------------------------------------------------+
 | Author: Jose Chen <jose@airli.cn>                                       |
 | Author: Airli Tian <im@airli.cn>                                        |
 +-------------------------------------------------------------------------+
*/
	//设置时区
	date_default_timezone_set('PRC');
	//读取内容
	@$string=file_get_contents('index/txt/wzy.txt');
	//如果$string不为空的时候执行，也就是home.txt中有留言数据
	if(!empty($string)){
		//每一段留言有一个分隔符，但是最后多出了一个&^。因此，我们需要将$^删掉
		$string=rtrim($string,'&^');
		//以&^切成数组
		$arr=explode('&^',$string);
		//将网站内容读取
		foreach($arr as $value){
			list($title,$content,$author,$bqsm,$time)=explode('$#',$value);
			echo '<title>'.$title.'</title>';
			echo '<body>
	<div class="container" style="margin-top:9%;">
  		<div class="jumbotron">
        <div class="panel panel-success">';
			echo '<div class="panel-heading"><h1>'.$content.'</h1></div></div>';
			echo '<p><li>by&nbsp'.$author.'</li></p>';
			echo '<p><li>最后更新于：'.date('Y-m-d H:i:s',$time);'</li></p>';
			echo '<p><li>'.$bqsm.'</li></p>';

		}
	}
?>
        </div>
	</div>
</body>
</html>