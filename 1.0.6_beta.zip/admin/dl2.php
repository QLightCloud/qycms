
} else {
		echo "您还没有登录,请<a href='/qyadmin/login.html'>登录</a>";
	}