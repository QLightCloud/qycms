<?php
/**
<?php 
	header('Content-type:text/html; charset=utf-8');
	session_start();
	if (isset($_COOKIE['username'])) {
		$_SESSION['username'] = $_COOKIE['username'];
		$_SESSION['islogin'] = 1;
	}
	if (isset($_SESSION['islogin'])) {
		echo "你好! ".$_SESSION['username'].' ,欢迎来到首页修改!<br>';
		echo "<a href='/qyadmin/logout.php'>注销</a>";
?>
<?php
/**
 +-------------------------------------------------------------------------+
 |                           轻云科技旗下项目                              |
 |                                                                         |
 | Author: Jose Chen <jose@airli.cn>                                       |
 | Author: Airli Tian <im@airli.cn>                                        |
 +-------------------------------------------------------------------------+
*/