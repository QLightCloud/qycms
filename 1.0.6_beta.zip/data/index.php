<?php
/**
 +-------------------------------------------------------------------------+
 |                           轻云科技旗下项目                              |
 |                                                                         |
 | Author: Jose Chen <jose@airli.cn>                                       |
 | Author: Airli Tian <im@airli.cn>                                        |
 +-------------------------------------------------------------------------+
*/
	date_default_timezone_set('PRC');
	@$string=file_get_contents('data.php');
	if(!empty($string)){
		$string=rtrim($string,'₱?>');
		$arr=explode('₱',$string);
		foreach($arr as $value){
			list($title,$head,$body1)=explode('<?php','₡',$value);
		}
	}
?>
<!doctype html>
<html>
<head>
<script>  
 var _hmt = _hmt || []; 
 (function() { 
 var hm = document.createElement("script"); 
 hm.src = "https://www.airli.cn/io/tongji/airli.php"; 
 var s = document.getElementsByTagName("script")[0]; 
 s.parentNode.insertBefore(hm, s); 
 })();  
 </script> 
<?php echo '<title>'.$title.'</title>' ?>
<meta charset="utf-8">
<?php echo ''.$head.'' ?>
</head>
<body>
<?php echo ''.$body1.'' ?>
</body>
</html>