<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="//cdn.bootcss.com/bootstrap/3.3.4/css/bootstrap.min.css">
<link rel="stylesheet" href="/img/css/menu.css">
<script>  
 var _hmt = _hmt || []; 
 (function() { 
 var hm = document.createElement("script"); 
 hm.src = "https://www.airli.cn/io/tongji/airli.php"; 
 var s = document.getElementsByTagName("script")[0]; 
 s.parentNode.insertBefore(hm, s); 
 })();  
 </script> 
</head>
<body>
<ul class="menu">
<li><a class="menu" href="/">首页</a></li>
<li><a class="menu" href="/wzy.php">文章页</a></li>
<li><a class="menu" href="/zdy.php">自定义页</a></li>
</ul>
</body>
<?php
/**
 +-------------------------------------------------------------------------+
 | Author: Jose Chen <jose@airli.cn>                                       |
 | Author: Airli Tian <im@airli.cn>                                        |
 +-------------------------------------------------------------------------+
*/
	date_default_timezone_set('PRC');
	@$string=file_get_contents('index/txt/home.txt');
	if(!empty($string)){
		$string=rtrim($string,'&^');
		$arr=explode('&^',$string);
		foreach($arr as $value){
			list($title,$content,$author,$bqsm,$tjdm,$time)=explode('$#',$value);
			echo '<title>'.$title.'</title>';
			echo '<body>
	<div class="container" style="margin-top:9%;">
  		<div class="jumbotron">
        <div class="panel panel-success">';
			echo '<div class="panel-heading"><h1>'.$content.'</h1></div></div>';
			echo '<p><li>by&nbsp'.$author.'</li></p>';
			echo '<p><li>最后更新于：'.date('Y-m-d H:i:s',$time);'</li></p>';
			echo '<p><li>'.$bqsm.'</li></p>';
		}
	}
?>
<?php
            echo '<body>'.$tjdm.'</body>'
?>
        </div>
	</div>
</body>
</html>