<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>轻云CMS后台</title>
<link rel="stylesheet" href="//cdn.bootcss.com/bootstrap/3.3.4/css/bootstrap.min.css">
<script src="https://cdn.bootcss.com/jquery/1.11.2/jquery.min.js"></script>
<script src="https://cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
<script>  
 var _hmt = _hmt || []; 
 (function() { 
 var hm = document.createElement("script"); 
 hm.src = "https://www.airli.cn/io/tongji/airli.php"; 
 var s = document.getElementsByTagName("script")[0]; 
 s.parentNode.insertBefore(hm, s); 
 })();  
 </script> 
</head>
<body>
	<div class="container" style="margin-top:9%;">
  		<div class="jumbotron">
        <div class="panel panel-success">
        <div class="panel-heading">
<h1>轻云CMS后台</h1></div>
        </div>
          <p><h3>请选择要修改的页面</h3></p>
          <p><li ><a href="home.php" title="首页" >首页</a></li></p>
          <p><li ><a href="wzy.php" title="文章页" >文章页</a></li></p>
          <p><li ><a href="zdy.php" title="文章页" >自定义页</a></li></p>
        </div>
	</div>
</body>
</html>