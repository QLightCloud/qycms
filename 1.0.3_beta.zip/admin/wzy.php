<?php
/**
 +-------------------------------------------------------------------------+
 | Author: Jose Chen <jose@airli.cn>                                                   |
 | Author: Airli Tian <im@airli.cn>			          |
 +-------------------------------------------------------------------------+
*/

			echo '<!DOCTYPE html>';
			echo '<html lang="en">';
			echo '<head>';
			echo '<meta charset="UTF-8">';
			echo '<title>轻云CMS后台 - 文章页修改</title>';
			echo '</head>';
			echo '<body>';

	//读取内容
	@$string=file_get_contents('../index/txt/wz.txt');
	//如果$string不为空的时候执行，也就是wzy.txt中有数据
	if(!empty($string)){
	//每一段留言有一个分隔符，但是最后多出了一个&^。因此，我们需要将$^删掉
	$string=rtrim($string,'&^');
	//以&^切成数组
	$arr=explode('&^',$string);
	//将网站内容读取
	foreach($arr as $value){
			list($title,$wztitle,$content,$author,$bqsm,$tagg,$time)=explode('$#',$value);

		}
	}
?>
<?php

			echo '<form action="wzyf.php" method="post">';
			echo '文章标题：<input type="text" name="title" value="'.$title.'" ><br/>';
			echo '文章内容：<br/><textarea name="content">'.$wztitle.'</textarea><br/>';
			echo '文章标签：<input type="text" name="tagg" value="'.$tagg.'" ><br/>';
			echo '文章内容：<br/><textarea name="content">'.$content.'</textarea><br/>';
			echo '文章作者：<br/><textarea name="author">'.$author.'</textarea><br/>';
			echo '版权声明：<br/><textarea name="bqsm">'.$bqsm.'</textarea><br/>';
			echo '<input type="submit" value="添加文章"/>';
			echo '</form>';
			echo '</body></html>';
?>
<a>如需删除文章，请自行前往网站txt目录里的wz.txt进行修改或删除！</a>