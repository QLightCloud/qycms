<?php include("./templetea/in/zdy/head.html") ?>
<?php include("./templetea/in/zdy/contect.html") ?>
<?php include("./templetea/in/zdy/footer.html") ?>