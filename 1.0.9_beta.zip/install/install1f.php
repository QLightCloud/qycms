<?php
	$fp=fopen('../index/txt/admin.txt','a');
	$aduse=trim($_POST['aduse']);
	$adpass=trim($_POST['adpass']);
	$oeiwsj='1';
	$string=$aduse.'₡'.$adpass.'₡'.$oeiwsj.'₱';

	file_put_contents('../index/txt/admin.txt','');
	fwrite($fp,$string);
	fclose($fp);
 
	header('location:install1.php');
?>