<?php
$hans=trim($_POST['line']);

function del_str_line($file,$line){
$str='';
$handle = @fopen("../index/txt/wz.txt", "rb+");
if ($handle) {
for($i=0;$i<$line;$i++){
   $str=fgets($handle);
}
rewind($handle);
$len=strlen($str);
for($i=0;$i<$line-1;$i++){
   fgets($handle);
}
for($n=1;$n<=$len-1;$n++){
   fwrite($handle,' ',1);
}
} 
}
?>
<?php
$line=trim($_POST['hans']);
del_str_line ('../index/txt/wz.txt',$line);
	header('location:wzs.php');
?>