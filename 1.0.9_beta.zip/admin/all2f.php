<?php
/**
 +-------------------------------------------------------------------------+
 |                           轻云科技旗下项目                              |
 |                                                                         |
 | Author: Jose Chen <jose@airli.cn>                                       |
 | Author: Airli Tian <im@airli.cn>                                        |
 +-------------------------------------------------------------------------+
*/
	date_default_timezone_set('PRC');
	@$string=file_get_contents('../index/txt/admin.txt');
	if(!empty($string)){
		$string=rtrim($string,'₱');
		$arr=explode('₱',$string);
		foreach($arr as $value){
			list($w,$e,$oeiwsj1)=explode('₡',$value);
		}
	}
?>
<?php
	$fp=fopen('../index/txt/admin.txt','a');
	$aduse=trim($_POST['aduse']);
	$adpass=trim($_POST['adpass']);
	$oeiwsj2=''.$oeiwsj1.'';
	$string=$aduse.'₡'.$adpass.'₡'.$oeiwsj2.'₱';

	file_put_contents('../index/txt/admin.txt','');
	fwrite($fp,$string);
	fclose($fp);
 
	header('location:all.php');
?>