<html><title>轻云CMS后台</title>
<meta charset="utf-8">
<script> 
 var _hmt = _hmt || []; 
 (function() { 
 var hm = document.createElement("script"); 
 hm.src = "https://www.airli.cn/io/tongji/airli.php"; 
 var s = document.getElementsByTagName("script")[0]; 
 s.parentNode.insertBefore(hm, s); 
 })();  
 </script>  
<?php 
	header('Content-type:text/html; charset=utf-8');
	session_start();
	if (isset($_COOKIE['username'])) {
		$_SESSION['username'] = $_COOKIE['username'];
		$_SESSION['islogin'] = 1;
	}
	if (isset($_SESSION['islogin'])) {
		echo "你好! ".$_SESSION['username'].' ,欢迎来到轻云CMS后台!<br>';
		echo "<a href='/qyadmin/logout.php'>注销</a>";
?>

<meta charset="utf-8">
<link rel="stylesheet" href="//cdn.bootcss.com/bootstrap/3.3.4/css/bootstrap.min.css">
<script src="//cdn.bootcss.com/jquery/1.11.2/jquery.min.js"></script>
<script src="//cdn.bootcss.com/bootstrap/3.3.4/js/bootstrap.min.js"></script></head>

<body>
<div class="container" style="margin-top:9%;"> 
<div class="jumbotron">
<div class="panel panel-success">
<div class="panel-heading">
<h1>轻云CMS后台</h1></div> 
</div>
<p><h3>请选择要修改的页面</h3></p>
<p><li ><a href="home.php" title="首页" >首页</a></li></p>
<p><li ><a href="wzy.php" title="文章页" >文章页</a></li></p>
<p><li ><a href="zdy.php" title="文章页" >自定义页</a></li></p>
</div>
</div>
</body>
<?php
} else {
		echo "您还没有登录,请<a href='/qyadmin/login.html'>登录</a>";
	}
 ?>

</html>