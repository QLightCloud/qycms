<?php 
	header('Content-type:text/html; charset=utf-8');
	session_start();
	if (isset($_COOKIE['username'])) {
		$_SESSION['username'] = $_COOKIE['username'];
		$_SESSION['islogin'] = 1;
	}
	if (isset($_SESSION['islogin'])) {
		echo "你好! ".$_SESSION['username'].' ,欢迎来到自定义页修改!<br>';
		echo "<a href='/qyadmin/logout.php'>注销</a>";
?>
<?php
/**
 +-------------------------------------------------------------------------+
 | Author: Jose Chen <jose@airli.cn>                                       |
 | Author: Airli Tian <im@airli.cn>                                        |
 +-------------------------------------------------------------------------+
*/

			echo '<!DOCTYPE html>';
			echo '<html lang="en">';
			echo '<head>';
			echo '<meta charset="UTF-8">';
			echo '<title>轻云CMS后台 - 自定义页面修改</title>';
			echo '</head>';
			echo '<body>';
	@$string=file_get_contents('../index/txt/zdy.txt');
	if(!empty($string)){
	$string=rtrim($string,'₱');
	$arr=explode('₱',$string);
	foreach($arr as $value){
			list($title,$head,$body1,$body2,$body3,$body4)=explode('₡',$value);
			echo '<form action="zdyf.php" method="post">';
			echo '网站标题：<input type="text" name="title" value="'.$title.'" ><br/>';
			echo '网站head：<br/><textarea name="head">'.$head.'</textarea><br/>';
			echo '网站body1：<br/><textarea name="body1">'.$body1.'</textarea><br/>';
			echo '网站body2：<br/><textarea name="body2">'.$body2.'</textarea><br/>';
			echo '网站body3：<br/><textarea name="body3">'.$body3.'</textarea><br/>';
			echo '网站body3：<br/><textarea name="body4">'.$body4.'</textarea><br/>';
			echo '<input type="submit" value="修改"/>';
			echo '</form>';
			echo '</body></html>';
		}
	}
?>
<?php
} else {
		echo "您还没有登录,请<a href='/qyadmin/login.html'>登录</a>";
	}
 ?>