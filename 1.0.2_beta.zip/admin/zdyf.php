<?php
	//追加方式打开文件
	$fp=fopen('../index/txt/zdy.txt','a');
	//得到标题
	$title=trim($_POST['title']);
	//得到head
	$head=trim($_POST['head']);
	//得到body1
	$body1=trim($_POST['body1']);
	//得到body2
	$body2=trim($_POST['body2']);
	//得到body3
	$body3=trim($_POST['body3']);
	//得到body4
	$body3=trim($_POST['body4']);
 
	//组合写入的字符串：内容和用户之间分开，使用特殊符号行与行之间分开
	//   $#'.$nr. 
	$string=$title.'₡'.$head.'₡'.$body1.'₡'.$body2.'₡'.$body3.'₡'.$body4.'₱';
	//写入文件
	file_put_contents('../index/txt/zdy.txt','');
	fwrite($fp,$string);
	//关闭文件
	fclose($fp);
 
	header('location:zdy.php');
?>
