<?php
	//追加方式打开文件
	$fp=fopen('../index/txt/wz.txt','a');
	//设置时间
	$time=time();
	//得到标题
	$title=trim($_POST['title']);
	//得到作者
	$author=trim($_POST['author']);
	//得到内容
	$content=trim($_POST['content']);
	//得到版权声明
	$bqsm=trim($_POST['bqsm']);
	//得到标签
	$tagg=trim($_POST['tagg']);
 
	//组合写入的字符串：内容和用户之间分开，使用$#行与行之间分开，使用&^
	//   $#'.$nr. 
	//$title,$wztitle,$content,$author,$bqsm,$tagg,$time
	$string=$title.'$#'.$wztitle.'$#'.$content.'$#'.$author.'$#'.$bqsm.'$#'.$tagg.'$#'.$time.'&^';
	//写入文件
	//file_put_contents('../index/txt/wz.txt','');
	fwrite($fp,$string);
	//关闭文件
	fclose($fp);
 
	header('location:wzy.php');
?>
