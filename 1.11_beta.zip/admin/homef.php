<?php require("../templetea/ahtdoc.php"); ?>
<?php
	$fp=fopen('../index/txt/home.txt','a');
	$time=time();
	$title=trim($_POST['title']);
	$author=trim($_POST['author']);
	$content=trim($_POST['content']);
	$bqsm=trim($_POST['bqsm']);
	$tjdm=trim($_POST['tjdm']);
	$string=$title.'$#'.$content.'$#'.$author.'$#'.$bqsm.'$#'.$tjdm.'$#'.$time.'&^';
	file_put_contents('../index/txt/home.txt','');
	fwrite($fp,$string);
	fclose($fp);
	header('location:home.php');
?>