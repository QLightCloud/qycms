<?php require("../templetea/ahtdoc.php"); ?>
<?php
	$fp=fopen('../index/txt/all.txt','a');
	$favicon=trim($_POST['favicon']);
	$qq=trim($_POST['qq']);
	$wzdurl=trim($_POST['wzdurl']);
	$string=$favicon.'¤○'.$qq.'¤○'.$wzdurl.'₪₢';
	file_put_contents('../index/txt/all.txt','');
	fwrite($fp,$string);
	fclose($fp);
	header('location:all.php');
?>