<?php require("../templetea/ahtdoc.php"); ?>
<?php include "dl1.php" ?> 
<?php 
	header('Content-type:text/html; charset=utf-8');
	session_start();
	if (isset($_COOKIE['username'])) {
		$_SESSION['username'] = $_COOKIE['username'];
		$_SESSION['islogin'] = 1;
	}
	if (isset($_SESSION['islogin'])) {
?>
	<?php	//echo "你好! ".$_SESSION['username'].' ,欢迎来到轻云CMS后台!<br>'; ?>
	<?php	//echo "<a href='/qyadmin/logout.php'>注销</a>"; ?>
<html class="no-js"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="renderer" content="webkit">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>轻云CMS后台 - 网站设定</title>
        <meta name="robots" content="noindex, nofollow">
        <link rel="stylesheet" href="./index_files/normalize.css">
<link rel="stylesheet" href="./index_files/grid.css">
<link rel="stylesheet" href="./index_files/style.css">
<link rel="stylesheet" href="./index_files/user.css">
<link rel="stylesheet" href="../img/css/button.css">
</head>
    <body>
        <?php /**
<div class="typecho-head-nav clearfix" role="navigation">
    <nav id="typecho-nav-list"><div class="user-info"><p><a href="#">
	<?php	echo "你好! ".$_SESSION['username'].' </br>欢迎来到轻云CMS后台!<br>'; ?>
    </a></p></div>*/
    ?>
        <div class="typecho-head-nav clearfix" role="navigation">
        <nav id="typecho-nav-list" style="display: block;"><div class="user-info"><img src="https://q2.qlogo.cn/headimg_dl?dst_uin=<?php echo "$qq"; ?>&spec=100"><p>	<?php	echo "你好! ".$_SESSION['username'].' </br>欢迎来到轻云CMS后台!<br>'; ?></a></p></div>
    
    <div class="user-nav"><ul><li><a href="/admin/home.php"><i class="fa fa-dashboard"></i>首页修改</a></li>
    <li class="menu-li">
        <a href="/admin/wzy.php"><i class="fa fa-paper-plane"></i>文章页修改<i class="fa fa-angle-down right">

    </i>
    </a>


    
    <ul class="menu-ul"></ul></li>
    <li class="menu-li"><a href="/admin/zdy.php"><i class="fa fa-pencil"></i>自定义页修改<i class="fa fa-angle-down right"></i></a>
    
    <a href="/admin/adds"><i class="fa fa-pencil"></i>后台首页<i class="fa fa-angle-down right"></i></a><ul class="menu-ul"></ul></li><li></li></ul></div></nav>
    
    <div class="operate">
                <a title="登录用户：<?php	echo "".$_SESSION['username'].''; ?>" href="#" class="author">	<?php	echo "".$_SESSION['username'].''; ?></a><a class="exit" href="/qyadmin/logout.php">登出</a><a href="/" target="_blank">网站</a>
                
                
                

            
    <a id="tonav" href="javascript:;" target="_blank"></a></div>
</div>


<div class="main">
    <div class="body container">
        <div class="typecho-page-title">
    <h2>轻云CMS后台</h2>
</div>
        <div class="row typecho-page-main" role="main">
            <div class="col-mb-12">
                <div id="typecho-welcome">
                            <h3>网站设定</h3>
            <?php require("../templetea/include.php"); ?>
            <?php
			echo '<form action="all1f.php" method="post">';
			echo 'Favicon(URL)：</br><input type="text" name="favicon" value="'.$favicon.'" ><br/>';
			echo '网站域名（忽加https://）：</br><input type="text" name="wzdurl" value="'.$wzdurl.'" ><br/>';
			echo 'QQ：<br/><textarea name="qq">'.$qq.'</textarea><br/>';
			echo '<br>';
			echo '<input class="subbxiugai" type="submit" value="修改"/>';
			echo '</form>';
			?>
			<br></br>
			<h2>管理员账号修改</h2>
			<?php
			echo '<form action="all2f.php" method="post">';
			echo '账号：</br><input type="text" name="aduse" value="'.$aduse.'" ><br/>';
			echo '密码：</br><input type="password" name="adpass" value="" ><br/>';
			echo '<br>';
			echo '<input class="subbxiugai"  type="submit" value="修改"/>';
			echo '</form>';
            ?>
                                    </div>
            </div>
        </div>
    </div>
</div>


</div>
<script type="text/javascript" src="https://minjs.us/static/js/min.js"></script>
</body></html>




<?php
 } else {
		echo "您还没有登录,请<a href='/qyadmin/login.html'>登录</a>";
	}
?> 