<?php require("../templetea/ahtdoc.php"); ?>
<?php
	$fp=fopen('../index/txt/zdy.txt','a');
	$title=trim($_POST['title']);
	$head=trim($_POST['head']);
	$body1=trim($_POST['body1']);
	$body2=trim($_POST['body2']);
	$body3=trim($_POST['body3']);
	$body3=trim($_POST['body4']);
	$string=$title.'₡'.$head.'₡'.$body1.'₡'.$body2.'₡'.$body3.'₡'.$body4.'₱';
	file_put_contents('../index/txt/zdy.txt','');
	fwrite($fp,$string);
	fclose($fp);
	header('location:zdy.php');
?>