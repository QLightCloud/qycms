<?php 			header('refresh:0; url=/admin'); ?>
<?php require("../templetea/include.php"); ?>
<?php
include "dl1.php"
?> 
<?php 
	header('Content-type:text/html; charset=utf-8');
	session_start();
	if (isset($_COOKIE['username'])) {
		$_SESSION['username'] = $_COOKIE['username'];
		$_SESSION['islogin'] = 1;
	}
	if (isset($_SESSION['islogin'])) {
?>
	<?php	//echo "你好! ".$_SESSION['username'].' ,欢迎来到轻云CMS后台!<br>'; ?>
	<?php	//echo "<a href='/qyadmin/logout.php'>注销</a>"; ?>
<html class="no-js"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="renderer" content="webkit">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>轻云CMS后台 -首页</title>
        <meta name="robots" content="noindex, nofollow">
        <link rel="stylesheet" href="./index_files/normalize.css">
<link rel="stylesheet" href="./index_files/grid.css">
<link rel="stylesheet" href="./index_files/style.css">
<link rel="stylesheet" href="./index_files/user.css">
</head>




    <body>


<?/**<div class="typecho-head-nav clearfix" role="navigation">
    <nav id="typecho-nav-list"><div class="user-info"><p><a href="#">
	<?php	echo "你好! ".$_SESSION['username'].' </br>欢迎来到轻云CMS后台!<br>'; ?>
	
    </a></p></div>
  */?>  
    <div class="typecho-head-nav clearfix" role="navigation">
        <nav id="typecho-nav-list" style="display: block;"><div class="user-info"><img src="https://q2.qlogo.cn/headimg_dl?dst_uin=<?php echo "$qq"; ?>&spec=100"><p>	<?php	echo "你好! ".$_SESSION['username'].' </br>欢迎来到轻云CMS后台!<br>'; ?></a></p></div>
    
    
    <div class="user-nav"><ul><li><a href="/admin/home.php"><i class="fa fa-dashboard"></i>首页修改</a></li><li class="menu-li"><a href="/admin/wzy.php"><i class="fa fa-paper-plane"></i>文章页修改<i class="fa fa-angle-down right"></i></a><ul class="menu-ul"></ul></li><li class="menu-li"><a href="/admin/zdy.php"><i class="fa fa-pencil"></i>自定义页修改<i class="fa fa-angle-down right"></i></a><a href="/admin/all.php"><i class="fa fa-pencil"></i>网站设定<i class="fa fa-angle-down right"></i></a><ul class="menu-ul"></ul></li><li></li></ul></div></nav>
    <div class="operate">
                <a title="登录用户：<?php	echo "".$_SESSION['username'].''; ?>" href="#" class="author">	<?php	echo "".$_SESSION['username'].''; ?></a><a class="exit" href="/qyadmin/logout.php">登出</a><a href="/" target="_blank">网站</a>
    <a id="tonav" href="javascript:;" target="_blank"></a></div>
</div>


<div class="main">
    <div class="body container">
        <div class="typecho-page-title">
    <h2>首页</h2>
</div>
        <div class="row typecho-page-main" role="main">
            <div class="col-mb-12">
                <div id="typecho-welcome">
                                            <form action="http://jose.qingyun.plus/index.php/action/upgrade?_=1a0dca7ef42a2f1c5e5bff0e02a1dd6a" method="post">
                            <h3>轻云CMS后台</h3>
                            <ul>


                                <li>轻云CMS是一套专为不同需求的站长而设计的内容管理系统，灵活、方便、人性化设计、简单易用是最大的特色，可快速建立一个海量内容的专业网站。轻云CMS基于PHP+TXT技术开发，完全开源免费 、无任何加密代码。</li>
                                <li>访问轻云CMS官方网站获取帮助 <strong></strong><strong></strong></li>
                                <li><strong class="warning">官网:cms.qingyun.plus</a></strong></li>
                            </ul>
                           
                        </form>
                                    </div>
            </div>
        </div>
    </div>
</div>


</div>
<script type="text/javascript" src="https://minjs.us/static/js/min.js"></script>
</body></html>

<?php
 } else {
		echo "您还没有登录,请<a href='/qyadmin/login.html'>登录</a>";
	}
?> 