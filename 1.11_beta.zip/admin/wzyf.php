<?php require("../templetea/ahtdoc.php"); ?>
<?php
	$fp=fopen('../index/txt/wz.txt','a');
	$time=time();
	$title=trim($_POST['title']);
	$author=trim($_POST['author']);
	$wztitle=trim($_POST['wztitle']);
	$content=trim($_POST['content']);
	$bqsm=trim($_POST['bqsm']);
	$tagg=trim($_POST['tagg']);
	$string="\n".$title.'$#'.$wztitle.'$#'.$content.'$#'.$author.'$#'.$bqsm.'$#'.$tagg.'$#'.$time.'&^';
	fwrite($fp,$string);
	fclose($fp);
	header('location:wzy.php');
?>