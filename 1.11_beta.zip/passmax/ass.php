<?php
if ($w='w'){
    $yija= 'a';
    $yijb= 'b';
    $yijc= 'c';
    $yijd= 'd';
    $yije= 'e';
    $yijf= 'f';
    $yijg= 'g';
    $yijh= 'h';
    $yiji= 'i';
    $yijj= 'j';
    $yijk= 'k';
    $yijl= 'l';
    $yijm= 'm';
    $yijo= 'o';
    $yijp= 'p';
    $yijq= 'q';
    $yijr= 'r';
    $yijs= 's';
    $yijt= 't';
    $yiju= 'u';
    $yijv= 'v';
    $yijw= 'w';
    $yijx= 'x';
    $yijy= 'y';
    $yijz= 'z';



    $zia= '1';
    $zib= '2';
    $zic= '3';
    $zid= '4';
    $zie= '5';
    $zif= '6';
    $zig= '7';
    $zih= '8';
    $zii= '9';
    $zij= '0';



    
}
//include("./passmax/ass.php")

?>
