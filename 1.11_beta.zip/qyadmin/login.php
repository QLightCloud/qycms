<?php
/**
	@$string=file_get_contents('../index/txt/admin.txt');
	if(!empty($string)){
	$string=rtrim($string,'₱');
	$arr=explode('₱',$string);
	foreach($arr as $value){
			list($aduse,$adpass,$installe1)=explode('₡',$value);
	}
	}
?>

<?php
	header('Content-type:text/html; charset=utf-8');
	session_start();
	if (isset($_POST['login'])) {
		$username = trim($_POST['username']);
		$password = trim($_POST['password']);
		if (($username == '') || ($password == '')) {
			header('refresh:3; url=login.html');
			echo "用户名或密码不能为空,系统将在3秒后跳转到登录界面,请重新填写登录信息!";
			exit;
		} elseif (($username != $aduse) || ($password != $adpass)) {
			header('refresh:3; url=login.html');
			echo "用户名或密码错误,系统将在3秒后跳转到登录界面,请重新填写登录信息!";
			exit;
		} elseif (($username = $aduse) && ($password = $adpass)) {

			$_SESSION['username'] = $username;
			$_SESSION['islogin'] = 1;
			if ($_POST['remember'] == "yes") {
				setcookie('username', $username, time()+7*24*60*60);
				setcookie('code', md5($username.md5($password)), time()+7*24*60*60);
			} else {
				setcookie('username', '', time()-999);
				setcookie('code', '', time()-999);
			}
			header('location:/admin/index.php');
		}
	}
	*/
	?>

<?php
	if (isset($_REQUEST['authcode'])) {
		session_start();
		if (strtolower($_REQUEST['authcode'])==$_SESSION['authcode']) {
			echo'<font color ="#0000CC">验证码正确，即将跳转</font>';

	@$string=file_get_contents('../index/txt/admin.txt');
	if(!empty($string)){
	$string=rtrim($string,'₱');
	$arr=explode('₱',$string);
	foreach($arr as $value){
			list($adusew,$adpassj,$installe1)=explode('₡',$value);
	}
	}
?>
<?php //require("../templetea/htdoc.php"); ?>
<?php  
//函数encrypt($string,$operation,$key)中$string：需要加密解密的字符串；$operation：判断是加密还是解密，E表示加密，D表示解密；$key：密匙。  
function encrypt($string,$operation,$key=''){   
    $key=md5($key);   
    $key_length=strlen($key);   
      $string=$operation=='D'?base64_decode($string):substr(md5($string.$key),0,8).$string;   
    $string_length=strlen($string);   
    $rndkey=$box=array();   
    $result='';   
    for($i=0;$i<=255;$i++){   
           $rndkey[$i]=ord($key[$i%$key_length]);   
        $box[$i]=$i;   
    }   
    for($j=$i=0;$i<256;$i++){   
        $j=($j+$box[$i]+$rndkey[$i])%256;   
        $tmp=$box[$i];   
        $box[$i]=$box[$j];   
        $box[$j]=$tmp;   
    }   
    for($a=$j=$i=0;$i<$string_length;$i++){   
        $a=($a+1)%256;   
        $j=($j+$box[$a])%256;   
        $tmp=$box[$a];   
        $box[$a]=$box[$j];   
        $box[$j]=$tmp;   
        $result.=chr(ord($string[$i])^($box[($box[$a]+$box[$j])%256]));   
    }   
    if($operation=='D'){   
        if(substr($result,0,8)==substr(md5(substr($result,8).$key),0,8)){   
            return substr($result,8);   
        }else{   
            return'';   
        }   
    }else{   
        return str_replace('=','',base64_encode($result));   
    }   
} 

	header('Content-type:text/html; charset=utf-8');
	session_start();
	if (isset($_POST['login'])) {
		$usernamew = trim($_POST['username']);
		$passwordw = trim($_POST['password']);

$str = $passwordw;   
$key = 'www';   
$token = encrypt($str, 'E', $key);   
//echo '加密:'.encrypt($str, 'E', $key);   
//echo '解密：'.encrypt($str, 'D', $key);  
$jadpass = encrypt($str, 'E', $key);
//$jiemidpass = encrypt($jiamidpass, 'D', $key); 

?>  
<?php
		if (($usernamew == '') || ($passwordw == '')) {
			header('refresh:3; url=login.html');
			echo "用户名或密码不能为空,系统将在3秒后跳转到登录界面,请重新填写登录信息!";
			exit;
		} elseif (($usernamew != $adusew) || ($jadpass != $adpassj)) {
			header('refresh:3; url=login.html');
			echo "用户名或密码错误,系统将在3秒后跳转到登录界面,请重新填写登录信息!";
			echo "</br>没有该用户“ $usernamew ”！";
			exit;
		} elseif (($usernamew = $adusew) && ($jadpass = $adpassj)) {

			$_SESSION['username'] = $usernamew;
			$_SESSION['islogin'] = 1;
			if ($_POST['remember'] == "yes") {
				setcookie('username', $usernamew, time()+7*24*60*60);
				setcookie('code', md5($usernamew.md5($jadpass)), time()+7*24*60*60);
			} else {
				setcookie('username', '', time()-999);
				setcookie('code', '', time()-999);
			}
			header('location:/admin/index.php');
		}
	}
?>
<?php
}else{
			//echo $_REQUEST['authcode'];
			//echo $_SESSION['authcode'];
			echo'<font color ="#CC0000">验证码错误</font>';
			header('location:./login.html');
		}
		exit();
	}
	?>