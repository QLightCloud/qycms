<?php include("./templetea/in/zdy/head.html") ?>
<?php include("./templetea/in/zdy/contect.html") ?>
<?php include("./templetea/in/zdy/footer.html") ?>
<?php
/**
if(isset($_GET['id'])){
    $page = $_GET['id'];
    function getFileRows($filename,$start,$num=0)
{
	date_default_timezone_set('PRC');
	@$string=file_get_contents('./index/txt/wz.txt');
	if(!empty($string)){
		$string=rtrim($string,'&^');
		$arr=explode('&^',$string);
		foreach($arr as $value){
			list($wzbtitle,$wztitle,$wzcontent,$wzauthor,$wzbqsm,$wztagg,$wztime)=explode('$#',$value);

		}
	}
$rowsdata = array();
$lines = file( $filename );
$start = $start -1;
$num = $num == 0 ? count($lines)-$start : $num;
for($i=0;$i<$num; $i++)
{
$k = $start + $i;
$rowsdata[] = $lines[$k];
}
return $rowsdata;
}
print_r(getFileRows('./index/txt/wz.txt',$page,1));

    echo $page;
}else{
    $page = 1;
    echo $page;
}
?>
<?php
*/
?>