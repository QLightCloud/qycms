<?php include("./templetea/in/index/head.html") ?>
<?php include("./templetea/in/index/contect.html") ?>
<?php include("./templetea/in/index/footer.html") ?>
<?php //include('./theplu/index.php'); ?>