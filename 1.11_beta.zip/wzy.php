<?php include("./templetea/in/wzy/head.html") ?>
<?php include("./templetea/in/wzy/contect.html") ?>
<?php include("./templetea/in/wzy/footer.html") ?>