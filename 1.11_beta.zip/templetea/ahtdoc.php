<?php
/**
 +-------------------------------------------------------------------------+
 |                           轻云科技旗下项目                              |
 |                                                                         |
 | Author: Jose Chen <jose@airli.cn>                                       |
 | Author: Airli Tian <im@airli.cn>                                        |
 +-------------------------------------------------------------------------+
*/
	date_default_timezone_set('PRC');
	@$string=file_get_contents('./index/txt/zdy.txt');
	if(!empty($string)){
		$string=rtrim($string,'₱');
		$arr=explode('₱',$string);
		foreach($arr as $value){
			list($zdytitle,$zdyhead,$zdybody1,$zdybody2,$zdybody3,$zdybody4)=explode('₡',$value);
		}
	}

	date_default_timezone_set('PRC');
	@$string=file_get_contents('./index/txt/wz.txt');
	if(!empty($string)){
		$string=rtrim($string,'&^');
		$arr=explode('&^',$string);
		foreach($arr as $value){
			list($wzbtitle,$wztitle,$wzcontent,$wzauthor,$wzbqsm,$wztagg,$wztime)=explode('$#',$value);

		}
	}

	date_default_timezone_set('PRC');
	@$string=file_get_contents('./index/txt/home.txt');
	if(!empty($string)){
		$string=rtrim($string,'&^');
		$arr=explode('&^',$string);
		foreach($arr as $value){
			list($hometitle,$homecontent,$homeauthor,$homebqsm,$hometjdm,$hometime)=explode('$#',$value);
		}
	}

	date_default_timezone_set('PRC');
	@$string=file_get_contents('./index/txt/all.txt');
	if(!empty($string)){
		$string=rtrim($string,'₪₢');
		$arr=explode('₪₢',$string);
		foreach($arr as $value){
			list($favicon,$qq,$wzdurl)=explode('¤○',$value);
		}
	}

	date_default_timezone_set('PRC');
	@$string=file_get_contents('../index/txt/zdy.txt');
	if(!empty($string)){
		$string=rtrim($string,'₱');
		$arr=explode('₱',$string);
		foreach($arr as $value){
			list($zdytitle,$zdyhead,$zdybody1,$zdybody2,$zdybody3,$zdybody4)=explode('₡',$value);
		}
	}

	date_default_timezone_set('PRC');
	@$string=file_get_contents('../index/txt/wz.txt');
	if(!empty($string)){
		$string=rtrim($string,'&^');
		$arr=explode('&^',$string);
		foreach($arr as $value){
			list($wzbtitle,$wztitle,$wzcontent,$wzauthor,$wzbqsm,$wztagg,$wztime)=explode('$#',$value);

		}
	}

	date_default_timezone_set('PRC');
	@$string=file_get_contents('../index/txt/home.txt');
	if(!empty($string)){
		$string=rtrim($string,'&^');
		$arr=explode('&^',$string);
		foreach($arr as $value){
			list($hometitle,$homecontent,$homeauthor,$homebqsm,$hometjdm,$hometime)=explode('$#',$value);
		}
	}

	date_default_timezone_set('PRC');
	@$string=file_get_contents('../index/txt/all.txt');
	if(!empty($string)){
		$string=rtrim($string,'₪₢');
		$arr=explode('₪₢',$string);
		foreach($arr as $value){
			list($favicon,$qq,$wzdurl)=explode('¤○',$value);
		}
	}
	date_default_timezone_set('PRC');
	@$string=file_get_contents('../index/txt/title.txt');
	if(!empty($string)){
		$string=rtrim($string,'₪₢');
		$arr=explode('₪₢',$string);
		foreach($arr as $value){
			list($hobt,$newsbt,$zdybt)=explode('¤○',$value);
		}
	}
	date_default_timezone_set('PRC');
	@$string=file_get_contents('./index/txt/title.txt');
	if(!empty($string)){
		$string=rtrim($string,'₪₢');
		$arr=explode('₪₢',$string);
		foreach($arr as $value){
			list($hobt,$newsbt,$zdybt)=explode('¤○',$value);
		}
	}
	date_default_timezone_set('PRC');
	@$string=file_get_contents('../index/txt/all.txt');
	if(!empty($string)){
		$string=rtrim($string,'₪₢');
		$arr=explode('₪₢',$string);
		foreach($arr as $value){
			list($favicon,$qq,$wzdurl)=explode('¤○',$value);
		}
	}
	date_default_timezone_set('PRC');
	@$string=file_get_contents('./index/txt/all.txt');
	if(!empty($string)){
		$string=rtrim($string,'₪₢');
		$arr=explode('₪₢',$string);
		foreach($arr as $value){
			list($favicon,$qq,$wzdurl)=explode('¤○',$value);
		}
	}
	
            
            if ($filepath = '../pl/pl.txt' );
            $plline = count(file($filepath));
            if ($plhans = $plline - 1);



@$a111=file('./index/txt/wean.txt');
@$a111=file('../index/txt/wean.txt');
?>
