<?php
$sjsss = rand (0, 33);
?>
<?php
$vqycms = "https://raw.githubusercontent.com/QLightCloud/qycms/main/wean.txt";
$vcms = file_get_contents($vqycms);
?>
<?php $a111=file($vqycms);
echo $a111[$sjsss];
?>