<?php
	
	$fp=fopen('./pl.txt','a');
	
	$pltime=time();
	
	$plauthor=trim($_POST['plauthor']);
	
	$plcontent=trim($_POST['plcontent']);
	
	$plqqm=trim($_POST['plqq']);

    $plurl=trim($_POST['plurl']);
    
    $plqqs=strpos($plqqm,"@qq.com");
    $k = "";
    $plqq=substr_replace($plqqm,$k,$plqqs,7);

	$string= ("\n".$plauthor.'$#'.$plcontent.'$#'.$plqq.'$#'.$plurl.'$#'.$pltime.'&^');
	fwrite($fp,$string);
	fclose($fp);
header('location:/wzy.php');
?>