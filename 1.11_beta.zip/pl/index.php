<section class="section section-components bg-secondary content-card-container">
<div class="container container-lg py-5 align-items-center content-card-container">
<div class="card shadow content-card list-card content-card-head">
<section class="section">
<div class="container" id="comments">
<div class="content">
<div class="row align-items-center justify-content-center">
<h3>已经有<?php echo $plline; ?> 条评论啦</h3>
</div>
<?php //$gwip =$_SERVER ['REMOTE_ADDR']; echo"$gwip";?>
<?php
	date_default_timezone_set('PRC');
	@$string=file_get_contents('./pl/pl.txt');
	if(!empty($string)){
		$string=rtrim($string,'&^');
		$arr=explode('&^',$string);
		foreach($arr as $value){
			list($plauthor,$plcontent,$plqq,$plurl,$pltime)=explode('$#',$value);
			echo '<hr/>';
?>

<ol class="comment-list"> 
<li id="li-comment-279">
<div class="comment-children">
<ol class="comment-list"> 
<li id="li-comment-281">
<div id="comment-281">
<div class="comment-item">
<div class="comment-parent">
<img class="avatar" src="https://q1.qlogo.cn/g?b=qq&nk=<?php echo $plqq; ?>&s=640" alt="<?php echo "$plauthor"; ?>" width="80" height="80"></div>
<div class="comment-body">
<div class="comment-head">
<h5><a href="<?php echo $plurl; ?>" rel="external nofollow"><?php echo "$plauthor"; ?></a> · <small> <?php echo date('Y-m-d H:i:s',$pltime); ;?></h5>
</small>
<span class="badge badge-pill badge-primary"><i class="fa fa-user-o" aria-hidden="true"></i> <?php echo "$plauthor"; ?> </span></h5>
</div>
<p><?php echo "$plcontent"; ?></p>
<div style="float: right;">
</div>
</div>
</div>
</div>
</li>
</ol>
</div>
</li>
</ol>
<?php
		}
	}
?>
<div class="row align-items-center justify-content-center"><nav class="page-nav"></nav></div>
<div class="comment-card">
<div id="respond-page-493" class="comment-reply">
<div class="row align-items-center justify-content-center">
<h3 id="response">发表评论</h3>
</div>
<br>
<form method="post" action="./pl/plf.php" id="comment-form" role="form" class="container" style="overflow: auto; zoom: 1;">
<div class="row">
<div class="col-md-4">
<div class="form-group">
<div class="input-group mb-4">
<div class="input-group-prepend">
<span class="input-group-text"><i class="fa fa-user-o" aria-hidden="true"></i></span>
</div>
<input type="text" name="plauthor" id="author" class="form-control" placeholder="你叫什么呐" value="" required="">
</div>
</div>
</div>
<div class="col-md-4">
<div class="form-group">
<div class="input-group mb-4">
<div class="input-group-prepend">
<span class="input-group-text"><i class="fa fa-envelope-o" aria-hidden="true"></i></span>
</div>
<input type="email" name="plqq" id="mail" class="form-control" placeholder="QQ邮箱哦" value="" required="">
</div>
</div>
</div>
<div class="col-md-4">
<div class="form-group">
<div class="input-group mb-4">
<div class="input-group-prepend">
<span class="input-group-text"><i class="fa fa-globe" aria-hidden="true"></i></span>
</div>
<input type="url" name="plurl" id="url" class="form-control" placeholder="你的网站呀" value="">
</div>
</div>
</div>
</div>
<p>
<textarea rows="8" cols="50" name="plcontent" id="textarea" class="form-control" required="">评论后默认视为已阅读隐私政策,本站默认执行净网行动！</textarea>
</p>
<p>
<button type="submit" class="btn btn-outline-success" id="add-comment-button" style="float: right;">提交评论</button>
</p>
<input type="hidden" name="" value=""></form>
</div>
</div>
</div>
</div>
</section>
</div>