<?php
/**
 +-------------------------------------------------------------------------+
 |                           轻云科技旗下项目                              |
 |                                                                         |
 | Author: Jose Chen <jose@airli.cn>                                       |
 | Author: Airli Tian <im@airli.cn>                                        |
 +-------------------------------------------------------------------------+
*/
	date_default_timezone_set('PRC');
	@$string=file_get_contents('index/txt/wz.txt');
	if(!empty($string)){
		$string=rtrim($string,'&^');
		$arr=explode('&^',$string);
		foreach($arr as $value){
			list($title,$wztitle,$content,$author,$bqsm,$tagg,$time)=explode('$#',$value);
			echo '<title>'.$title.' - 轻云CMS</title>';
?>
		<section class="section section-components bg-secondary content-card-container">
			<div class="container container-lg py-5 align-items-center content-card-container">
				<!-- Article list -->
		<div class="card shadow content-card list-card content-card-head">
		<section class="section">
			<div class="container">
				<div class="content">
					<h1><a class="text-default"><?echo "$content"; ?></a></h1>
					<div class="list-object">
						<span class="list-tag"><i class="fa fa-calendar-o" aria-hidden="true"></i> <?php echo ''.date('Y-m-d H:i:s',$time);''; ?></span>
						<!--<span class="list-tag"><i class="fa fa-comments-o" aria-hidden="true"></i></span>-->
							<span class="list-tag">
		<i class="fa fa-folder-o" aria-hidden="true"></i>
		<a class="badge badge-info badge-pill"><?php echo "$tagg";?></a>
		</span>
		<span class="list-tag">
		<i class="fa fa-tags" aria-hidden="true"></i>
		<a  class="badge badge-success badge-pill"><?php echo "$tagg";?></a>
		</span>
		<span class="list-tag"><i class="fa fa-user-o" aria-hidden="true"></i>
		<a class="badge badge-warning badge-pill"><?php echo "$author"; ?></a></span>
		</div>
		<p><strong><?php echo "$wztitle";?></strong><br><strong></strong></p><br/>

		</div>
		</div>
		</section>
	</div></div></div>
<?php
		}
	}
?>