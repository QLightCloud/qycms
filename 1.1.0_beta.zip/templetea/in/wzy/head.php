<?php include("./templetea/htdoc.php") ?>
<?php require("./templetea/include.php"); ?>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<script>  
 var _hmt = _hmt || []; 
 (function() { 
 var hm = document.createElement("script"); 
 hm.src = "https://www.airli.cn/io/tongji/airli.php"; 
 var s = document.getElementsByTagName("script")[0]; 
 s.parentNode.insertBefore(hm, s); 
 })();  
 </script> 
<link rel="stylesheet" href="/img/css/menu.css">
<link href="<?php echo "$favicon" ?>" rel="icon" type="image/png">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link type="text/css" href="https://www.airli.cn/usr/themes/Bubble/assets/css/main.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/katex@0.11.1/dist/katex.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/prismjs@1.20.0/themes/prism-coy.css">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/prismjs@1.20.0/plugins/toolbar/prism-toolbar.css">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/prismjs@1.20.0/plugins/line-numbers/prism-line-numbers.css">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/viewerjs/dist/viewer.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.4.1/dist/jquery.min.js"></script>
<style type="text/css">
</style>
		<!-- Viewer.js Plugin -->
	<script src="https://cdn.jsdelivr.net/npm/viewerjs/dist/viewer.min.js"></script>
	<script src="https://cdn.jsdelivr.net/gh/fengyuanchen/jquery-viewer@master/dist/jquery-viewer.min.js"></script>
<link rel="stylesheet" type="text/css" href="usr/plugins/WTS/notify2.css">
<link rel="stylesheet" type="text/css" href="/DPlayer.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.0/clipboard.min.js"></script>
<link rel="stylesheet" type="text/css" href="img/css/wzy.css">
<body>
<ul class="menu" class="menuz">
<li><a class="menu" class="menuz" href="/">首页</a></li>
<li><a class="menu" class="menuz" href="/wzy.php">文章页</a></li>
<li><a class="menu" class="menuz" href="/zdy.php">自定义页</a></li>
</ul>
</body>
</br></br></br>
<!--
<ul class="mee">
  <li class="mee"><a class="mee" href=""></a></li>
  <li class="mee"><a class="mee" href=""></a></li>
  <li class="mee">
    <a href="" class="mee"></a>
    </div>
  </li>
</ul>
<style>
.mee ul .mee {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}

.mee li {
    float: left;
}

.mee li .mee, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

.mee li .mee:hover, .dropdown:hover .dropbtn {
    background-color: #3d3d3d;
}

.mee li .dropdown {
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

.dropdown-content .mee {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.dropdown-content .mee:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
    display: block;
}
</style>
</br></br></br>-->