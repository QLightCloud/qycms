<?php //include("./templetea/wean.php") ?>
</body>
	<footer class="footer">
		<div class="container">
						<div class="row">
				<div class="col-md-4 widget" title="希望每一笔绘画都是澄净的未来">
</div>
				<div class="col-md-4 widget">

				</div>
				<div class="col-md-4 widget">

				</div>
			</div>
			<hr/>
						<div class="row">
				<div class="col-md-6">
					<div class="copyright">
						<a  target="_blank" style="display:inline-block;" rel="twipsy" 	title="版权声明"></a> <a  style="color:#1E90FF" title="版权声明"><?php echo "$bqsm";?></a></span></center> </p><span id="copyright" style="display:none;"></span>					</div>
				</div>
				<div class="col-md-6">
					<ul class="nav nav-footer justify-content-end">
						<li class="nav-item">
							<a class="nav-link" ><?php include ("./templetea/wean.php")  ?></a>
						</li>
											</ul>
				</div>
			</div>
		</div>
	</footer>
</html>