<?php include("./templetea/in/wzy/head.php") ?>
<?php include("./templetea/in/wzy/contect.php") ?>
<?php include("./templetea/in/wzy/footer.php") ?>