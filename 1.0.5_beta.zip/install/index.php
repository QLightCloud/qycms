<?php
	@$string=file_get_contents('../index/txt/admin.txt');
	if(!empty($string)){
	$string=rtrim($string,'₱');
	$arr=explode('₱',$string);
	foreach($arr as $value){
			list($aduser,$adpass,$installe1)=explode('₡',$value);
?>
<?php
if ($installe1 > 0) {

	    echo "该系统已安装完成，如果你未曾安装，或许你使用了别人开发的版本，请从官方渠道下载正版！";
		exit ;
		    
		} elseif ($installe1 < 1) {

		 ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>欢迎 | 轻云CMS安装</title>
        <link href="css/style.min.css" rel="stylesheet"/>

    </head>
    <body>
        <div class="master">
            <div class="box">
                <div class="header">
                    <h1 class="header__title">轻云CMS安装
</h1>
                </div>

                <div class="main">
			<form action="install1f.php" method="post">

      <div class="form-group">
        <label>后台账号</label>
        <input type="text" name="aduse" placeholder="后台账号" value="" required>
      </div>
      <div class="form-group">
        <label>后台密码</label>
        <input type="password" name="adpass" placeholder="后台密码" required>
      </div>
      <p class="text-center">
        <button type="submit" class="button">下一步 </button>
      </p>
    </form>
                </div>
            </div>
        </div>
                <script type="text/javascript">
            var x = document.getElementById('error_alert');
            var y = document.getElementById('close_alert');
            y.onclick = function() {
                x.style.display = "none";
            };
        </script>
    </body>
</html>
<?php
exit ;
		    
		}}}

?>