<?php 
	header('Content-type:text/html; charset=utf-8');
	session_start();
	if (isset($_COOKIE['username'])) {
		$_SESSION['username'] = $_COOKIE['username'];
		$_SESSION['islogin'] = 1;
	}
	if (isset($_SESSION['islogin'])) {
		echo "你好! ".$_SESSION['username'].' ,欢迎来到文章页修改!<br>';
		echo "<a href='/qyadmin/logout.php'>注销</a>";
?>
<?php
/**
 +-------------------------------------------------------------------------+
 |                           轻云科技旗下项目                              |
 |                                                                         |
 | Author: Jose Chen <jose@airli.cn>                                       |
 | Author: Airli Tian <im@airli.cn>                                        |
 +-------------------------------------------------------------------------+
*/

			echo '<!DOCTYPE html>';
			echo '<html lang="en">';
			echo '<head>';
			echo '<meta charset="UTF-8">';
			echo '<title>轻云CMS后台 - 文章页修改</title>';
			echo '</head>';
			echo '<body>';
	@$string=file_get_contents('../index/txt/wz.txt');
	if(!empty($string)){
	$string=rtrim($string,'&^');
	$arr=explode('&^',$string);
	foreach($arr as $value){
			list($title,$wztitle,$content,$author,$bqsm,$tagg,$time)=explode('$#',$value);
		}
	}
?>
<?php

			echo '<form action="wzyf.php" method="post">';
			echo '文章标题：<input type="text" name="title" value="'.$title.'" ><br/>';
			echo '文章内容：<br/><textarea name="content">'.$wztitle.'</textarea><br/>';
			echo '文章标签：<input type="text" name="tagg" value="'.$tagg.'" ><br/>';
			echo '文章内容：<br/><textarea name="content">'.$content.'</textarea><br/>';
			echo '文章作者：<br/><textarea name="author">'.$author.'</textarea><br/>';
			echo '版权声明：<br/><textarea name="bqsm">'.$bqsm.'</textarea><br/>';
			echo '<input type="submit" value="添加文章"/>';
			echo '</form>';
			echo '</body></html>';
?>
<a>如需删除文章，请自行前往网站txt目录里的wz.txt进行修改或删除！</a>

<?php
} else {
		echo "您还没有登录,请<a href='/qyadmin/login.html'>登录</a>";
	}
 ?>